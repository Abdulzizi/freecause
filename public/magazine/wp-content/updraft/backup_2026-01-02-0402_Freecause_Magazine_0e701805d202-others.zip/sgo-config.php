<?php
$config = array (
  'ignored_query_params' => 
  array (
    0 => 'fbclid',
    1 => 'fb_action_ids',
    2 => 'fb_action_types',
    3 => 'fb_source',
    4 => '_ga',
    5 => 'age-verified',
    6 => 'ao_noptimize',
    7 => 'usqp',
    8 => 'cn-reloaded',
    9 => 'klaviyo',
    10 => 'amp',
    11 => 'gclid',
    12 => 'utm_source',
    13 => 'utm_medium',
    14 => 'utm_campaign',
    15 => 'utm_content',
    16 => 'utm_term',
    17 => '_locale',
  ),
  'bypass_query_params' => 
  array (
  ),
  'bypass_cookies' => 
  array (
    0 => 'woocommerce_items_in_cart',
    1 => 'edd_items_in_cart',
    2 => 'wordpress_logged_in_',
    3 => 'wpSGCacheBypass',
    4 => 'comment_author_',
  ),
  'output_dir' => '/mnt/BLOCKSTORAGE/home/1366246.cloudwaysapps.com/bpdefxwugd/public_html/magazine/wp-content/cache/sgo-cache/',
  'logged_in_cache' => 0,
  'cache_secret_key' => 'edc7cb16c3dfffda0d9490ad1467ae27',
  'logged_in_cookie' => 'wordpress_logged_in_c92bb4c3b3329f1976c65e3bfaf74fe2',
);
